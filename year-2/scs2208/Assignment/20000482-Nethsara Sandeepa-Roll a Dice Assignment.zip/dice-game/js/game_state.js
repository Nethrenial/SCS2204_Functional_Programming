export const gameState = {
    stage: 'welcome',
    player1: {
        name: null,
        score: 0,
        turn: false,
    },
    player2: {
        name: null,
        score: 0,
        turn: false,
    },
    round: 1,
}