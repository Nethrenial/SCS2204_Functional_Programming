export const scoreboardScreen = document.querySelector(".scoreboard-screen");
export const scoreboard = document.querySelector('.scoreboard')
export const scoreboardTitle = document.querySelector('.scoreboard-screen h1')
export const noRecords = document.querySelector('.scoreboard-screen .no-records')