export const buttons = document.querySelectorAll(".btn");
