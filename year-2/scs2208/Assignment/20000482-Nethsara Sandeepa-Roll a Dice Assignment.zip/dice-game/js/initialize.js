import {gameState} from './game_state.js'


gameState.player1.name = ""
gameState.player2.name = ""
gameState.stage = "welcome"
gameState.player1.turn = true
gameState.player2.turn = false
gameState.player1.score = 0
gameState.player2.score = 0


