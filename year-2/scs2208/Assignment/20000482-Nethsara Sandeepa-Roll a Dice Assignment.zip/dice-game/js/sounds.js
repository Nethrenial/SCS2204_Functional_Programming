export const diceSound  = new Audio('../sounds/dice.wav');
export const mouseClick = new Audio('../sounds/mouse-click.m4a');